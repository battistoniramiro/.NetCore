﻿
namespace Packagroup.Ecommerce.Transversal.common
{
    public class Response<T>
    {
        public T Data { get; set; }
        public bool ISuccess { get; set; }
        public string message { get; set; }

    }
}
