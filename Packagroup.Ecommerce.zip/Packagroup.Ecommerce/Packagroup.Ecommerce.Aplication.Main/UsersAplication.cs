﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using System.Net.Cache;
using Packagroup.Ecommerce.Domain.Interface;
using Packagroup.Ecommerce.Aplication.Interface;
using packagroup.Ecommerce.Aplication.DTO;
using Packagroup.Ecommerce.Transversal.common;

namespace Packagroup.Ecommerce.Aplication.Main
{
    public class UsersAplication : IUsersAplication
    {
        private readonly IUsersDomain _usersDomain;
        private readonly IMapper _mapper;

        public UsersAplication(IUsersDomain usersDomain , IMapper iMapper)
        {
            _usersDomain = usersDomain;
            _mapper = iMapper;
        }

        public Response<UsersDTO> Authenticate(string username ,string password)
        {
            var response = new Response<UsersDTO>();
            if(string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                response.message = "Parametros no pueden ser Vacios";
                return response;
            }
            try
            {
                var user = _usersDomain.Authenticate(username, password);
                response.Data = _mapper.Map<UsersDTO>(user);
                response.ISuccess = true;
                response.message = "Autenticacion Exitosa!";
            }
            catch(InvalidOperationException)
            {
                response.ISuccess = true;
                response.message = "Usuario no Existe!!";
            }
            catch(Exception e)
            {
                response.message = e.Message;
                
            }
            return response;
        }
    }
}
