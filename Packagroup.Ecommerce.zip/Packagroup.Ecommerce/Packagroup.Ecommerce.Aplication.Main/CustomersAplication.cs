﻿using AutoMapper;
using packagroup.Ecommerce.Aplication.DTO;
using packagroup.Ecommerce.Domain.Interface;
using Packagroup.Ecommerce.Aplication.Interface;
using Packagroup.Ecommerce.Transversal.common;
using Packagruop.Ecommerce.Domain.Entity;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Packagroup.Ecommerce.Aplication.Main
{
    public class CustomersAplication :ICustomerAplication
    {

        private readonly ICustomersDomain _customersDomain;
        private readonly IMapper _mapper;
        private readonly IAppLogger<CustomersAplication> _appLogger;
        public CustomersAplication (ICustomersDomain customersDomain,IMapper mapper , IAppLogger<CustomersAplication> logger)
        {
            _customersDomain = customersDomain;
            _mapper = mapper;
            _appLogger = logger;
        }

        #region Metodos Sincronos
        public Response<bool> Insert(CustomersDto customersDto)
        {
            var response = new Response<bool>();
            try
            {
                var customer = _mapper.Map<Customers>(customersDto);
                response.Data = _customersDomain.Insert(customer);
                if (response.Data == true)
                {
                    response.ISuccess = true;
                    response.message = "Registro Exitoso!!";
                }
            }
            catch (Exception e)
            {
                response.message = e.Message;
            }
            return response;
        }
        public Response<bool> Update(CustomersDto customersDto)
        {

            var response = new Response<bool>();
            try
            {
                var customer = _mapper.Map<Customers>(customersDto);
                response.Data = _customersDomain.Update(customer);
                if (response.Data == true)
                {
                    response.ISuccess = true;
                    response.message = "Actualización Exitosa!!";
                }
            }
            catch (Exception e)
            {
                response.message = e.Message;
            }
            return response;

        }
        public Response<bool> Delete(string CustomerId)
        {

            var response = new Response<bool>();
            try
            {
                response.Data = _customersDomain.Delete(CustomerId);
                if (response.Data == true)
                {
                    response.ISuccess = true;
                    response.message = "Eliminación Exitosa!!";
                }
            }
            catch (Exception e)
            {
                response.message = e.Message;
            }
            return response;
        }
        public Response<CustomersDto> Get(string CustomerId)
        {

            var response = new Response<CustomersDto>();
            try
            {
                var customer = _customersDomain.Get(CustomerId);
                response.Data = _mapper.Map<CustomersDto>(customer);
                if (response.Data!=null)
                {
                    response.ISuccess = true;
                    response.message = "Consulta Exitosa!!";
                }
            }
            catch (Exception e)
            {
                response.message = e.Message;
            }
            return response;
        }
        public Response<IEnumerable<CustomersDto>> GetAll()
        {

            var response = new Response<IEnumerable<CustomersDto>>();
            try
            {
                var customers = _customersDomain.GetAll();

                response.Data = _mapper.Map<IEnumerable<CustomersDto>>(customers);
                if (response.Data != null)
                {
                    response.ISuccess = true;
                    response.message = "Consulta Exitosa!!";
                    _appLogger.LogInformation("Consulta Exitosa!!");
                }
            }
            catch (Exception e)
            {
                response.message = e.Message;
                _appLogger.LogError(e.Message);
            }
            return response;

        }
        #endregion


        #region Metodos Asincronos
       public async Task<Response<bool>> InsertAsync(CustomersDto customersDto)
        {

            var response = new Response<bool>();
            try
            {
                var customer = _mapper.Map<Customers>(customersDto);
                response.Data = await _customersDomain.InsertAsync(customer);
                if (response.Data == true)
                {
                    response.ISuccess = true;
                    response.message = "Registro Exitoso!!";
                }
            }
            catch (Exception e)
            {
                response.message = e.Message;
            }
            return response;

        }
        public async Task<Response<bool>> UpdateAsync(CustomersDto customersDto)
        {

            var response = new Response<bool>();
            try
            {
                var customer = _mapper.Map<Customers>(customersDto);
                response.Data = await _customersDomain.UpdateAsync(customer);
                if (response.Data == true)
                {
                    response.ISuccess = true;
                    response.message = "Actualización Exitosa!!";
                }
            }
            catch (Exception e)
            {
                response.message = e.Message;
            }
            return response;

        }
        public async Task<Response<bool>> DeleteAsync(string CustomerId)
        {

            var response = new Response<bool>();
            try
            {
                response.Data = await _customersDomain.DeleteAsync(CustomerId);
                if (response.Data == true)
                {
                    response.ISuccess = true;
                    response.message = "Eliminación Exitosa!!";
                }
            }
            catch (Exception e)
            {
                response.message = e.Message;
            }
            return response;
        }
        public async Task<Response<CustomersDto>> GetAsync(string CustomerId)
        {

            var response = new Response<CustomersDto>();
            try
            {
                var customer =await _customersDomain.GetAsync(CustomerId);

                response.Data = _mapper.Map<CustomersDto>(customer);
                if (response.Data != null)
                {
                    response.ISuccess = true;
                    response.message = "Consulta Exitosa!!";
                }
            }
            catch (Exception e)
            {
                response.message = e.Message;
            }
            return response;


        }
        public async Task<Response<IEnumerable<CustomersDto>>> GetAllAsync()
        {
            var response = new Response<IEnumerable<CustomersDto>>();
            try
            {
                var customers =await _customersDomain.GetAllAsync();

                response.Data = _mapper.Map<IEnumerable<CustomersDto>>(customers);
                if (response.Data != null)
                {
                    response.ISuccess = true;
                    response.message = "Consulta Exitosa!!";
                }
            }
            catch (Exception e)
            {
                response.message = e.Message;
            }
            return response;

        }
        #endregion



    }
}
