﻿using packagroup.Ecommerce.Aplication.DTO;
using Packagroup.Ecommerce.Transversal.common;

namespace Packagroup.Ecommerce.Aplication.Interface
{
    public  interface IUsersAplication
    {
        Response<UsersDTO> Authenticate(string username, string password);
    }
}
