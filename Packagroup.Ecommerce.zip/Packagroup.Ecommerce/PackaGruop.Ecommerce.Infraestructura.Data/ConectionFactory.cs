﻿using System;
using Packagroup.Ecommerce.Transversal.common;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace PackaGruop.Ecommerce.Infraestructura.Data
{
    public class ConectionFactory : IConnectionFactory
    {
        private readonly IConfiguration _configuration;
        public ConectionFactory(IConfiguration configuration)
        {
            _configuration = configuration;
        
        }

        public IDbConnection GetConnection
        {
            get
            {
                var sqlconnection = new SqlConnection();
                if (sqlconnection == null) return null;
                sqlconnection.ConnectionString = _configuration.GetConnectionString("NorthwindConnection");
                sqlconnection.Open();
                return sqlconnection;
            }
        }
    }
}
