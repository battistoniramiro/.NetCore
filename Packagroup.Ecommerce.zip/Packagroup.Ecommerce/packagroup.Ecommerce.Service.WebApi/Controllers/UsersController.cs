﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using packagroup.Ecommerce.Aplication.DTO;
using packagroup.Ecommerce.Service.WebApi.Helpers;
using Packagroup.Ecommerce.Aplication.Interface;
using Packagroup.Ecommerce.Transversal.common;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace packagroup.Ecommerce.Service.WebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class UsersController : Controller
    {
        private readonly IUsersAplication _usersAplication;
        private readonly AppSettings _appSettings;

        public UsersController(IUsersAplication authAplication, IOptions<AppSettings> appSetting)
        {
            _usersAplication = authAplication;
            _appSettings = appSetting.Value;
        }
        [AllowAnonymous]
        [HttpPost]
        public IActionResult Authenticate([FromBody]UsersDTO userDto)
        {
            var response = _usersAplication.Authenticate(userDto.UserName, userDto.Password);
            if(response.ISuccess==true)
            {
                if(response.Data!=null)
                {
                    response.Data.Token = BuildToken(response);
                    return Ok(response);
                }
                else 
                {
                    return NotFound(response.message);
                }
            }
            return BadRequest(response.message);
        }

        private string BuildToken(Response<UsersDTO> userDto)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_appSettings.Secret);
            var tokenDescriptor = new SecurityTokenDescriptor()
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Name, userDto.Data.UserId.ToString())
                }),
                Expires = DateTime.UtcNow.AddMinutes(1),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
                Issuer = _appSettings.Issuer,
                Audience = _appSettings.Audience
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            var tokenString = tokenHandler.WriteToken(token);
            return tokenString;

        }



    }
}
