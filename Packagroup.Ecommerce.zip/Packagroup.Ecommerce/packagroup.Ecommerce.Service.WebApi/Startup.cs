using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using AutoMapper;
using Packagroup.Ecommerce.Aplication.Interface;
using Packagroup.Ecommerce.Aplication.Main;
using Packagroup.Ecommerce.Domain.Core;
using Packagruop.Ecommerce.Domain.Entity;
using packagroup.Ecommerce.Domain.Interface;
using packagroup.Ecommerce.Infraestructura.Interface;
using packagroup.Ecommerce.Infraestructura.Repository;
using PackaGruop.Ecommerce.Infraestructura.Data;
using Packagroup.Ecommerce.Transversal.common;
using Packagroup.Ecommerce.Transversal.Mapper;
using Swashbuckle.AspNetCore.Swagger;
using Microsoft.VisualBasic;
using Microsoft.OpenApi.Models;
using System.Reflection;
using System.IO;
using packagroup.Ecommerce.Service.WebApi.Helpers;
using Packagroup.Ecommerce.Domain.Interface;
using Packagroup.Ecommerce.Infraestructura.Interface;
using Packagroup.Ecommerce.Infraestructura.Repository;
using System.Text;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.Net;
using Microsoft.AspNetCore.Authorization;
using Packagroup.Ecommerce.Transversal.Logging;
using Packagroup.Ecommerce.Transversal.common;
using System.Security.Cryptography.Xml;
using Castle.DynamicProxy.Generators.Emitters.SimpleAST;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace packagroup.Ecommerce.Service.WebApi
{
    public class Startup
    {
        readonly string myPolicy = "policyApiEcommerce";
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            var mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new MappingProfile());
            });
            services.AddAutoMapper(x => x.AddProfile(new MappingProfile()));
            
            services.AddCors(option => option.AddPolicy(myPolicy, builder => builder.WithOrigins(Configuration["Config:OriginCors"])
                                                                                    .AllowAnyHeader()
                                                                                    .AllowAnyMethod()));
                                                                                
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
            //AppSetting
            var appSettingSection = Configuration.GetSection("Config");
            var appSetting = appSettingSection.Get<AppSettings>();

            services.Configure<AppSettings>(appSettingSection);
            services.AddControllers();
            services.AddAuthentication();
            services.AddAuthorization();
            services.AddSingleton<IConfiguration>(Configuration);
            services.AddSingleton<IConnectionFactory,ConectionFactory>();
            services.AddScoped<ICustomerAplication, CustomersAplication>();
            services.AddScoped<ICustomersDomain, CustomersDomain>();
            services.AddScoped<ICustomersRepository, CustomerRepository>();
            services.AddScoped<IUsersAplication, UsersAplication>();
            services.AddScoped<IUsersDomain, UsersDomain>();
            services.AddScoped<IUsersRepository, UsersRepository>();
            services.AddScoped(typeof(IAppLogger<>), typeof(LoggerAdapter<>));



            var key = Encoding.ASCII.GetBytes(appSetting.Secret);
            var issuer = appSetting.Issuer;
            var audience = appSetting.Audience;

            services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(x =>
            {
                x.Events = new JwtBearerEvents
                {
                    OnTokenValidated = context =>
                     {
                         var UserId = int.Parse(context.Principal.Identity.Name);
                         return Task.CompletedTask;
                     },
                    OnAuthenticationFailed = context =>
                    {
                        if (context.Exception.GetType() == typeof(SecurityTokenExpiredException))
                        {
                            context.Response.Headers.Add("Token Expired", "true");
                        }
                        return Task.CompletedTask;
                    }
                };
                x.RequireHttpsMetadata = false;
                x.SaveToken = false;
                x.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = true,
                    ValidIssuer = issuer,
                    ValidateAudience = true,
                    ValidAudience = audience,
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.Zero
                };
            });

            services.AddSwaggerGen(c =>
             {
                 c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
                 {
                     Version = "v1",
                     Title = "Pacagroup Technology Service API Market",
                     Description = "Proyecto ASP.NET Core Web API",
                     TermsOfService = new Uri("Https://packagroup.com/Terms"),
                     Contact = new OpenApiContact   
                     {
                         Name = "Ramiro battistoni",
                         Email = "ramirobattistoni18@gmail.com",
                         Url = new Uri("Https://packagroup.com/Contact")
             },
                     License = new OpenApiLicense
                     {
                         Name = "Use under LICX",
                         Url = new Uri("https://example.com/license")
        }
                 }); ;
                 var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                 var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                 c.IncludeXmlComments(xmlPath);
                 c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                 {
                     Description = "Authorization by API key.",
                     In = ParameterLocation.Header,
                     Type =SecuritySchemeType.ApiKey,
                     Name = "Authorization"
                 });
                 c.AddSecurityRequirement(new OpenApiSecurityRequirement
                 {
                     {
                         new OpenApiSecurityScheme
                         {
                             Reference = new OpenApiReference
                             {
                                 Type = ReferenceType.SecurityScheme,
                                 Id = "Bearer"
                             }
                         },
                         new string []{}
                     }
                 });
             });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            //Habilitamos en Middleware para servir al Swagger generation  como un endpoint JSON
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json","Mi proyecto de Ecommerce API V1");
            });
            app.UseCors(myPolicy);
            app.UseAuthentication();
            app.UseRouting();
            app.UseAuthorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
