﻿using System;
using AutoMapper;
using packagroup.Ecommerce.Aplication.DTO;
using Packagruop.Ecommerce.Domain.Entity;
//ADMINISTRAR PAQUETES NUGETS Y DESCARGAR AUTOMAPPER 
//AGREGAR REFERENCIAS A LAS ENTITY Y DTO DEL PROYECYTO
//USING--
namespace Packagroup.Ecommerce.Transversal.Mapper
{
    public class MappingProfile: Profile
    {
        public MappingProfile()
        {   //En caso de que los atributos de la Entidad y el DTO sean iguales
            CreateMap<Customers, CustomersDto>().ReverseMap();
            //En caso de que los atributos de la Entidad y el DTO NO sean iguales
            CreateMap<Customers, CustomersDto>().ReverseMap()
                .ForMember(destination => destination.CustomerId, source => source.MapFrom(src => src.CustomerId));

            CreateMap<Users, UsersDTO>().ReverseMap();
            //En caso de que los atributos de la Entidad y el DTO NO sean iguales
            CreateMap<Users, UsersDTO>().ReverseMap()
                .ForMember(destination => destination.UserId, source => source.MapFrom(src => src.UserId));

        }
    }
}
