﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using packagroup.Ecommerce.Aplication.DTO;
using Packagroup.Ecommerce.Aplication.Interface;

namespace Packagroup.Ecommerce.Services.WebApi.Controllers
{
    [Route("api[controller]/[action]")]
    [ApiController]
    public class CustomersController : Controller
    {
        private readonly ICustomerAplication _customersAplication;
        public CustomersController(ICustomerAplication customerAplication)
        {
            _customersAplication = customerAplication;
        }


        #region  Metodos Sincronos
        [HttpPost]//metodo Post para insercion mediante solicitud
        public IActionResult Insert([FromBody]CustomersDto customersDto)
        {
            if (customersDto == null)
                return BadRequest();
            var response = _customersAplication.Insert(customersDto);
            if (response.ISuccess == true) // preguntamos si la solicitud fue correcta
                return Ok(response);
            return BadRequest(response.message); //si no es correcta o no devuelve nada devolvemos el mensage de response
        }

        [HttpPut]//metodo Put para modificacion mediante solicitud
        public IActionResult Update([FromBody] CustomersDto customersDto)
        {
            if (customersDto == null)
                return BadRequest();
            var response = _customersAplication.Update(customersDto);
            if (response.ISuccess == true)
                return Ok(response);
            return BadRequest(response.message);
        }

        
        [HttpDelete("{CustomerId}")]//metodo Put para Eliminacion mediante solicitud
        public IActionResult Delete(string CustomerId)
        {
            if (string.IsNullOrEmpty(CustomerId))
                return BadRequest();
            var response = _customersAplication.Delete(CustomerId);
            if (response.ISuccess == true)
                return Ok(response);
            return BadRequest(response.message);
        }


        [HttpGet("{CustomerId}")]//metodo Get para Consulta mediante solicitud
        public IActionResult Get(string CustomerId)
        {
            if (string.IsNullOrEmpty(CustomerId))
                return BadRequest();
            var response = _customersAplication.Get(CustomerId);
            if (response.ISuccess == true)
                return Ok(response);
            return BadRequest(response.message);
        }


        [HttpGet]//metodo Get para Consulta mediante solicitud
        public IActionResult GetAll()
        {
            var response = _customersAplication.GetAll();
            if (response.ISuccess == true)
                return Ok(response);
            return BadRequest(response.message);
        }
        #endregion
        #region Metodos Asyncronos

        [HttpPost]//metodo Post para insercion mediante solicitud
        public async Task<IActionResult> InsertAsync([FromBody] CustomersDto customersDto)
        {
            if (customersDto == null)
                return BadRequest();
            var response = await _customersAplication.InsertAsync(customersDto);
            if (response.ISuccess == true) // preguntamos si la solicitud fue correcta
                return Ok(response);
            return BadRequest(response.message); //si no es correcta o no devuelve nada devolvemos el mensage de response
        }

        [HttpPut]//metodo Put para modificacion mediante solicitud
        public async Task<IActionResult> UpdateAsync([FromBody] CustomersDto customersDto)
        {
            if (customersDto == null)
                return BadRequest();
            var response =await _customersAplication.UpdateAsync(customersDto);
            if (response.ISuccess == true)
                return Ok(response);
            return BadRequest(response.message);
        }


        [HttpDelete("{CustomerId}")]//metodo Delete para Eliminacion mediante solicitud
        public async Task<IActionResult> DeleteAsync(string CustomerId)
        {
            if (string.IsNullOrEmpty(CustomerId))
                return BadRequest();
            var response =await _customersAplication.DeleteAsync(CustomerId);
            if (response.ISuccess == true)
                return Ok(response);
            return BadRequest(response.message);
        }


        [HttpGet("{CustomerId}")]//metodo Get para Consulta mediante solicitud
        public async Task<IActionResult> GetAsync(string CustomerId)
        {
            if (string.IsNullOrEmpty(CustomerId))
                return BadRequest();
            var response =await _customersAplication.GetAsync(CustomerId);
            if (response.ISuccess == true)
                return Ok(response);
            return BadRequest(response.message);
        }


        [HttpGet]//metodo Get para Consulta mediante solicitud
        public async  Task<IActionResult> GetAllAsync()
        {
            var response = await _customersAplication.GetAllAsync();
            if (response.ISuccess == true)
                return Ok(response);
            return BadRequest(response.message);
        }


        #endregion








        
    }
}
