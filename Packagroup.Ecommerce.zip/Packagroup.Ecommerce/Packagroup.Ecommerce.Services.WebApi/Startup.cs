using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using AutoMapper;
using Packagroup.Ecommerce.Aplication.Main;
using Packagroup.Ecommerce.Aplication.Interface;
using Packagroup.Ecommerce.Transversal.common;
using Packagroup.Ecommerce.Transversal.Mapper;
using Packagroup.Ecommerce.Domain.Core;
using packagroup.Ecommerce.Domain.Interface;
using PackaGruop.Ecommerce.Infraestructura.Data;
using packagroup.Ecommerce.Infraestructura.Interface;
using packagroup.Ecommerce.Infraestructura.Repository;
using System.Diagnostics.Contracts;
using System.Runtime.Serialization.Json;
using System.Text.Json;
using System.Text.Encodings.Web;

namespace Packagroup.Ecommerce.Services.WebApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddAutoMapper(x => x.AddProfile(new MappingProfile()));
            services.AddSingleton<IConfiguration>(Configuration);
            services.AddSingleton<IConnectionFactory, ConectionFactory>();
            services.AddScoped<ICustomerAplication, CustomersAplication>();
            services.AddScoped<ICustomersDomain, CustomersDomain>();
            services.AddScoped<ICustomersRepository, CustomerRepository>();
            services.AddAuthorization();
            services.AddControllers();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
