﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Dapper;
using packagroup.Ecommerce.Infraestructura.Interface;
using Packagroup.Ecommerce.Infraestructura.Interface;
using Packagroup.Ecommerce.Transversal.common;
using Packagruop.Ecommerce.Domain.Entity;

namespace Packagroup.Ecommerce.Infraestructura.Repository
{
    public class UsersRepository :IUsersRepository
    {
        private readonly IConnectionFactory _connectionFactory;
        public UsersRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;

        }
        public Users Authenticate(string username,string password)
        {
            using (var connection = _connectionFactory.GetConnection)
            {
                var query = "UsersGetByUserAndPassword";
                var parameters = new DynamicParameters();
                parameters.Add("UserName", username);
                parameters.Add("Password",password);
                var user = connection.QuerySingle<Users>(query,param: parameters, commandType: CommandType.StoredProcedure);
                return user;
            }
        }

    }
}
