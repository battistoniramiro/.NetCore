﻿using System;
using System.Collections.Generic;
using System.Text;
using Packagruop.Ecommerce.Domain.Entity;
using Packagroup.Ecommerce.Domain.Interface;
using Packagroup.Ecommerce.Infraestructura.Interface;

namespace Packagroup.Ecommerce.Domain.Core
{
   public  class UsersDomain:IUsersDomain
    {

        private readonly IUsersRepository _userRepository;
        public UsersDomain(IUsersRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public Users Authenticate(string username,string password)
        {
            return _userRepository.Authenticate(username, password);
        }
    }
}
